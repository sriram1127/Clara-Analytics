import React, { Component } from 'react';
import '../styles/custom.css';
class Name extends Component {

  	render () {
  		return (
  			<div className="section1">
        <input type="text" id="fname" name="firstname" placeholder="First Name" pattern="[A-Za-z]{1,30}" maxLength="30" />
        <input type="text" id="lname" name="lastname" placeholder="Second Name" pattern="[A-Za-z]{1,30}" maxLength="30" />
        </div>
  		);
  	}
}

export default Name;
