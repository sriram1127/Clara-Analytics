import React, { Component } from 'react';
import Select from 'react-select';
import '../styles/custom.css';

const STATES = require('../data/states');

class Location extends Component {

  constructor(props) {
       super(props);

       this.state = {
         country: 'AU',
         disabled: false,
         searchable: this.props.searchable,
         selectValue: 'new-south-wales',
         clearable: true,
         rtl: false,
       }
    }


  	displayName: 'StatesField';
  	propTypes: {
  		label: PropTypes.string,
  		searchable: PropTypes.bool,
  	};


    static defaultProps = {
      label: 'States:',
      searchable: true,
  }

  	clearValue (e) {
  		this.select.setInputValue('');
  	}
  	switchCountry (e) {
  		var newCountry = e.target.value;
  		this.setState({
  			country: newCountry,
  			selectValue: null,
  		});
  	}

    updateValue(value)  {
      this.setState({
      selectValue: value
      });
    }

  	focusStateSelect () {
  		this.refs.stateSelect.focus();
  	}
  	toggleCheckbox (e) {
  		let newState = {};
  		newState[e.target.name] = e.target.checked;
  		this.setState(newState);
  	}
  	render () {
  		var options = STATES[this.state.country];
  		return (
        <div>
  			<div className="combosec1">
  				<Select style={{height:41 + 'px'}}
  					id="country-select"
  					ref={(ref) => { this.select = ref; }}
  					onBlurResetsInput={false}
  					onSelectResetsInput={false}
  					autoFocus
  					options={options}
  					simpleValue
  					clearable={this.state.clearable}
  					name="selected-state"
  					disabled={this.state.disabled}
  					value={this.state.selectValue}
  					onChange={this.updateValue.bind(this)}
  					rtl={this.state.rtl}
  					searchable={this.state.searchable}
  				/>
  			</div>

        <div className="combosec2">
          <Select style={{height:41 + 'px'}}
            id="state-select"
            ref={(ref) => { this.select = ref; }}
            onBlurResetsInput={false}
            onSelectResetsInput={false}
            autoFocus
            options={options}
            simpleValue
            clearable={this.state.clearable}
            name="selected-state"
            disabled={this.state.disabled}
            value={this.state.selectValue}
            onChange={this.updateValue.bind(this)}
            rtl={this.state.rtl}
            searchable={this.state.searchable}
          />
        </div>
      </div>


  		);
  	}
}

export default Location;
