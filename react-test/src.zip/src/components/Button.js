import React, { Component } from 'react';
import '../styles/custom.css';
class Button extends Component {

  	render () {
  		return (
  			<div className="button">
        <input id="btn" type="button" value="Submit" />
        </div>
  		);
  	}
}

export default Button;
