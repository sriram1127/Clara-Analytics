import React, { Component } from 'react';
import Location from './components/Location';
import Name from './components/Name';
import Button from './components/Button';
import 'react-select/dist/react-select.css'
import './styles/custom.css';
import logo from './clara.png';

class App extends Component {

  	render () {
      return(
        <div>
        <img src={logo} />
      <div id="box" className="center">
      <div id="heading">Enter Details</div>
      <Name />
      <Location />
      <Button />
      </div>
    </div>
  );
    }
}

export default App;
